<?php 
    echo do_shortcode('[elementor-template id="21722"]');
?>