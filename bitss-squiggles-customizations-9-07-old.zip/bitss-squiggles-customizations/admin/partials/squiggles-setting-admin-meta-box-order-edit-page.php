<?php 

    $sub_damages = get_post_meta( $active_subscription_id, 'sub_damages', true);
    if(empty($sub_damages)){
        $sub_damages =[];
    }
    $sub_damages = json_encode($sub_damages);
?>

<input id="sub_damages_table_data" type="hidden" value='<?= $sub_damages ?>'>
<?php foreach($items as $item): ?>
    <?php if($item->get_meta("issue_or_return")=='return'): 
$booked_copy_post_id = $item->get_meta("return_copy_post_id");
?>
<input id="sq_copy_id" type="hidden" value='<?php echo get_post_meta($booked_copy_post_id, 'wpcf-copy-id', true) ?>'>
<input id="sq_product_id" type="hidden" value='<?php echo $item->get_product_id() ?>'>
<?php endif; endforeach; ?>

<div class="field is-horizontal" style="display:unset !important">
    <div class="sq_squiggles_damage_inputs">
        <div class="sq_fields_and_labels">
            <div class="field-label is-normal">
                <label class="label">Reason:</label>
            </div>
            <div class="field-body">
                <div class="field">
                    
                    <div class="">
                        <select class="sq_amount_auto_cal" id="sq_mt_type">
                            <option  value=''>Select dropdown</option>
                            <option value='Ripped Pages'>Ripped Pages</option>
                            <option value='Liquid Damage'>Liquid Damage</option>
                            <option value='Book Lost'>Book Lost</option>
                            <option value='Other Damages'>Other Damages</option>
                        </select>
                    </div>
                    
                </div>
            </div>
        </div>
        <div class="sq_fields_and_labels">
            <div class="field-label is-normal">
                <label class="label">Severity:</label>
            </div>
            <div class="field-body">
                <div class="field">
                    <div class="">
                        <select class="sq_amount_auto_cal" id="sq_mt_severity">
                            <option value=''>Select dropdown</option>
                            <option value='1'>1</option>
                            <option value='2'>2</option>
                            <option value='3'>3</option>
                            <option value='4'>4</option>
                            <option value='5'>5</option>
                        </select>
                    </div>
                    
                </div>
            </div>
        </div>
        <div class="sq_fields_and_labels">
            <div class="field-label is-normal">
                <label class="label">Copy:</label>
            </div>
            <div class="field-body">
                <div class="field">
                    
                    <div class="">
                        <select class="sq_amount_auto_cal" id="sq_mt_copy">
                            <option value="">Select dropdown</option>
                            <?php foreach($items as $item): ?>
                                <?php if($item->get_meta("issue_or_return")=='return'): 
                            $booked_copy_post_id = $item->get_meta("return_copy_post_id");

                            $product_id = $item->get_product_id();
							$product_price = get_post_meta($product_id,'wpcf-mrp',true);
							$copy_price = get_post_meta($product_id,'wpcf-copy-mrp',true);
							if($copy_price){
								$price = $copy_price;
							}else{
								$price =$product_price;
							}

                            ?>
                                    <option data-product-price='<?php echo $price; ?>' value='<?php echo $item->get_name() . ' (' . get_post_meta($booked_copy_post_id, 'wpcf-copy-id', true) . ')'; ?>'><?php echo $item->get_name() . ' (' . get_post_meta($booked_copy_post_id, 'wpcf-copy-id', true) . ')'; ?></option>
                            <?php endif; endforeach; ?>
                        </select>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
    <div class="sq_squiggles_damage_inputs">
        <div class="sq_fields_and_labels">
            <div class="field-label is-normal">
                <label class="label">Date:</label>
            </div>
            <div class="field-body">
                <div class="field">
                    
                        <input class="input" id="sq_mt_date" type="date" placeholder="Date">
                    
                </div>
            </div>
        </div>
        <div class="sq_fields_and_labels">
            <div class="field-label is-normal">
                <label class="label">Amount:</label>
            </div>
            <div class="field-body">
                <div class="field">
                    
                        <input class="input" id="sq_mt_amt" type="number" placeholder="₹ Amount">
                    
                </div>
            </div>
        </div>
        <div class="sq_fields_and_labels">
            <div class="field-label is-normal">
                <label class="label">Remark:</label>
            </div>
            <div class="field-body">
                <div class="field">
                    
                        <input class="input" id="sq_mt_remark" type="text" placeholder="Remarks">
                    
                </div>
            </div>    
        </div>
    </div>
</div>
<div class="columns">
    <div class="column is-one-quarter">
        <input class="button button is-info" id="sq_mt_save_to_table" type="submit" value="Save Data">
        <span id="sq_spinner" class="spinner"></span>
    </div>
</div>

<div class="sq_sd_table table-container">
    <table class="table is-bordered" id="sub_damage_table">
        <thead>
            <tr>
                <th>S.No.</th>
                <th>Date</th>
                <th>Reason</th>
                <th>Severity</th>
                <th>Copy</th>
                <th>Amount</th>
                <th>Remark</th>
                <th>Added Order Id</th>
                <th>Paid Order Id</th>
            </tr>
        </thead>
        <tbody>
            
        </tbody>
    </table>
</div>

